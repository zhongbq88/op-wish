<?php
/**
 * Customizer functionality for the Theme Info section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Hook controls for Features section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_theme_info_customize_register( $wp_customize ) {
	require_once( trailingslashit( get_template_directory() ) . 'inc/customizer-theme-info/class-customizer-theme-info-control.php' );
	require_once( trailingslashit( get_template_directory() ) . 'inc/customizer-theme-info/class-customizer-theme-info-root.php' );

	$wp_customize->add_section( 'hestia_theme_info_main_section', array(
		'title'    => __( 'View PRO Features', 'hestia' ),
		'priority' => 0,
	) );

	$wp_customize->add_setting( 'hestia_theme_info_main_control', array(
		'sanitize_callback' => 'esc_html',
	) );

	$wp_customize->add_control( new Hestia_Control_Upsell_Theme_Info( $wp_customize, 'hestia_theme_info_main_control', array(
		'section'            => 'hestia_theme_info_main_section',
		'priority'           => 100,
		'options'            => array(
			esc_html__( 'Header Slider', 'hestia' ),
			esc_html__( 'Fully Customizable Colors', 'hestia' ),
			esc_html__( 'Jetpack Portfolio', 'hestia' ),
			esc_html__( 'Pricing Plans Section', 'hestia' ),
			esc_html__( 'Section Reordering', 'hestia' ),
			esc_html__( 'Quality Support', 'hestia' ),
		),
		'explained_features' => array(
			esc_html__( 'You will be able to add more content to your site header with an awesome slider.', 'hestia' ),
			esc_html__( 'Change colors for the header overlay, header text and navbar.', 'hestia' ),
			esc_html__( 'Portfolio section with two possible layouts.', 'hestia' ),
			esc_html__( 'A fully customizable pricing plans section.', 'hestia' ),
			esc_html__( 'The ability to reorganize your front page sections easy and fast.', 'hestia' ),
			esc_html__( '24/7 HelpDesk Professional Support.', 'hestia' ),
		),
		'button_url'         => esc_url( 'https://www.themeisle.com/themes/hestia-pro/' ),
		'button_text'        => esc_html__( 'Get the PRO version!', 'hestia' ),
	) ) );

}

add_action( 'customize_register', 'hestia_theme_info_customize_register' );

